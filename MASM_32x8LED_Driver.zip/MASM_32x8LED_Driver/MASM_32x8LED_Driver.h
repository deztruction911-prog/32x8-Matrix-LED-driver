/*
This is my custom library for the 32x8 (4 blocks of 8x8) matrixes. Please note that this library will
work only with said matrix.
*/


uint32_t volatile pixels[8]; // Memory buffer
uint8_t _pins[3]; // List for use in BootMatrix to assign pins

// This is meant to be like the OUTPUT/INPUT in pinMode()
#define PixelOn 1
#define ShiftUp 1
#define UpdatePixel 1
#define ShiftRight 1
#define PixelOff 0
#define NoUpdate 0
#define ShiftLeft 0
#define ShiftDown 0

// These are all commands for the matrix display
#define nop 0x00 // Tells the display to do nothing with the data it got
#define row1 0x01 // Very self explanatory
#define row2 0x02 // Very self explanatory
#define row3 0x03 // Very self explanatory
#define row4 0x04 // Very self explanatory
#define row5 0x05 // Very self explanatory
#define row6 0x06 // Very self explanatory
#define row7 0x07 // Very self explanatory
#define row8 0x08 // Very self explanatory
#define DecodeMode 0x09 // set to 0 for no decoding
#define brightness 0x0a // Set to 0x05 (self explanatory)
#define ScanLimit 0x0b  // Set to 0x07 (Make sure it sees all 8 rows)
#define shutdown 0x0c   // Set to 0x01 (Exit shutdown)
#define DispTest 0x0f   // Set to 0x00 (Exit display test)

// Set Chip Select low to send data
void WriteMode(){
  digitalWrite(_pins[2], LOW);
}

// Set Chip Select high to allow the Matrix to read latched data
void ReadMode(){
  digitalWrite(_pins[2], HIGH);
}

// Pulse the clock to shift bit internally
void pulse(){
  digitalWrite(_pins[1], HIGH);
  delayMicroseconds(10); // Delay to allow the signal to stabalise
  digitalWrite(_pins[1], LOW);
  delayMicroseconds(10);
}

// Send a single byte to the Matrix
void SendByte(uint8_t byte){
  WriteMode(); // Allow writing
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (byte>>i) & 1); // Send a bit, pulse clock to shift the bit, send next bit, etc
    pulse();
  }
  ReadMode(); // Tell it to read latched data
}

// Send a 16 bit pakcet consisting of a command (upper byte) and data (lower byte)
void SendPacket(uint8_t command, uint8_t data){
  // SendByte but 2 of it
  WriteMode();
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (command>>i) & 1); // Send the command first
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (data>>i) & 1); // Send data after command
    pulse();
  }
  ReadMode();
}

// Send a 64 bit packet of 4 commands and data for each
void SendFull(uint8_t cmda, uint8_t data, uint8_t cmdb, uint8_t datb, uint8_t cmdc, uint8_t datc, uint8_t cmdd, uint8_t datd){
  // It's just SendPacket but 4 times. It sets it to write/read mode only once, which is what we need
  // If we used SendPacket it would constantly overwritie the data of the previous packet as it won't
  // be able to "overflow" into the next block as we'll always set it write mode, send data, read mode,
  // write mode, send data, read mode, etc
  WriteMode();
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (cmda>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (data>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (cmdb>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (datb>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (cmdc>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (datc>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (cmdd>>i) & 1);
    pulse();
  }
  for(int i=7; i>=0; i--){
    digitalWrite(_pins[0], (datd>>i) & 1);
    pulse();
  }
  ReadMode();
}

// Display pixel memory to Matrix
void DisplayMemory(){
  // Do note that this function assumes the command is always send row. To send a command like DecodeMode
  // you'll have to use SendFull

  // The function works by sending 4 packets (setting row x), then the next 4 (setting row x+1), and so on
  // until every row has some data sent to it. The memory buffer is a 1:1 of the screen in MOST cases, as you'll see.
  // Since it's a 1:1, it allows the program to 'see' the screen and 'write' to any pixel they want
  for(int i=1; i<9; i++){
    SendFull(i, pixels[i-1]>>24, i, pixels[i-1]>>16, i, pixels[i-1]>>8, i, pixels[i-1]);
  }
}

// Change a row on the Matrix. RowData being 0000 0000 0000 0000 0000 0000 0000 0000 (32 bits)
// and each bit corresponding to it's respective LED on the row (bit 0 corresponding to the rightmost, 
// bit 1 corresponding to the one after, etc)
void SetRow(uint8_t row, uint32_t RowData, bool update){
  // If update is UpdatePixel, it will call DisplayMemory to push the buffer to the matrix.
  // If update is NoUpdate, it will only change the buffer values but won't push it to the matrix.
  pixels[row-1] = RowData;
  if(update){DisplayMemory();}
}

// Change a specific pixel on the Matrix
void EnablePixel(uint8_t yPos, uint8_t xPos, bool update){
  // Sets a certain pixel to 1 unocidtionally. The top corner of the closest column to the input pins
  // will be referred to as 0,0. 
  unsigned long PrevData = pixels[yPos]; // Get the old data of the row before it changed
  unsigned long bit = 1UL << xPos; // Shift a single bit by xPos to reach the intended bit
  PrevData |= bit; // OR the shifted bit with previous data to prevent setting anything to 0.
  SetRow(yPos+1, PrevData, update); // Since PrevData is the entire row, we can call SetRow
}

// Disable a chosen pixel on the Matrix
void DisablePixel(uint8_t yPos, uint8_t xPos, bool update){
  unsigned long PrevData = pixels[yPos];
  unsigned long bit = ~(1UL << xPos); // Unlike EnablePixel, the ~ will turn (1<<5) 0x00000010 into 0xffffffef
  PrevData &= bit; // This means when AND takes place here, only the bit we want will be affected. More detail in the README
  SetRow(yPos+1, PrevData, update);
}

// Toggle a pixel (invert it's state)
void TogglePixel(uint8_t yPos, uint8_t xPos, bool update){
  unsigned long PrevData = pixels[yPos];
  unsigned long bit = 1UL << xPos;
  PrevData ^= bit; // Uses XOR to set the bit to 1 if it's 0 or 0 if it's 1. Won't affect other bits as 1 XOR 0 is still 1
  SetRow(yPos+1, PrevData, update);
}

// Change a column on the matrix. Column data are represented by an 8 bit (0000 0000) value corresponding to 
// their pixels. With bit 0 being the top of the column. Columns are chosen from 1-32
void SetColumn(uint8_t ColNum, uint8_t ColData, bool update){
  for(int i = 0; i < 8; i++){ // E.X: (0b10011111(ColData)>>5(i)) & 1 = 0b100 & 1 which is 0. That means row 5 pixel 7(ColNum) will be set to 0
    if ((ColData >> i) & 1){ // If the bit we check is 1, then do the same thing we did for EnablePixel
      unsigned long PrevData = pixels[i];
      PrevData |= (1UL << ColNum);
      pixels[i] = PrevData;
    }else{ // Otherwise we do the same thing we did for DisablePixel
      unsigned long PrevData = pixels[i];
      PrevData &= ~(1UL << ColNum);
      pixels[i] = PrevData;
    }
  }
  // Do note that updating the display is always at the very end
  if(update){DisplayMemory();}
}

// Set a pixel on or off
void SetPixel(uint8_t yPos, uint8_t xPos, uint8_t state, bool update){
  // Set state to either PixelOn, or PixelOff
  if(state == PixelOn){
    EnablePixel(yPos, xPos, update);
  }else{
    DisablePixel(yPos, xPos, update);
  }
}

// Shift a pixel left or right
void ShiftPixel(uint8_t yPos, uint8_t xPos, bool dir, bool update){
  // Very simple. it shifts a pixel left is dir is ShiftLeft, if it's ShiftRight it shifts right.
  // It also makes sure if the pixel get's shifted off the edge, it get's wrapped around to the other side
  bool BitState = (pixels[yPos] >> xPos) & 1;
  DisablePixel(yPos, xPos, NoUpdate);
  if(dir == ShiftLeft){
    if(xPos == 31){
      SetPixel(yPos, 0, BitState, NoUpdate);
    }else{
      SetPixel(yPos, xPos+1, BitState, NoUpdate);
    }
  }
  if(dir == ShiftRight){
    if(xPos == 0){
      SetPixel(yPos, 31, BitState, NoUpdate);
    }else{
      SetPixel(yPos, xPos-1, BitState, NoUpdate);
    }
  }
  if(update){DisplayMemory();}
}

// Shift an entire row left or right
void ShiftRow(uint8_t RowNum, bool dir, bool update){
  // Shifts an entire row to the left (ShiftLeft) or right (ShiftRight). Uses the same wrapping logic
  RowNum--;
  uint32_t RowData = pixels[RowNum];
  if(dir){pixels[RowNum] = RowData >> 1| RowData << 31;}
  if(!dir){pixels[RowNum] = RowData << 1| RowData >> 31;}
  if(update){DisplayMemory();}
}

// Shift everything to the left or right
void ShiftAllRow(bool dir, bool update){
  // It shifts every row with the same wrapping logic. ShiftLeft and ShiftRight for shifting
  for(int i=1; i<9; i++){ShiftRow(i, dir, NoUpdate);}
  if(update){DisplayMemory();}
}

// Shift a column up or down
void ShiftCol(uint8_t ColNum, bool dir, bool update){
  // Uses wrap around. Shifts an entire column up (ShiftUp) or down (ShiftDown) 
  bool WrappedBit;
  unsigned long ColVal;
  if(dir){WrappedBit = (pixels[0] >> ColNum) & 1;}else{WrappedBit = (pixels[7] >> ColNum) & 1;}
  if(dir){
    for(int i=0; i<7; i++){
      pixels[i] &= ~(1UL << ColNum);
      ColVal = (((pixels[i+1] >> ColNum) & 1) << ColNum);
      pixels[i] |= ColVal;
    }
    ColVal = (uint32_t)WrappedBit << ColNum;
    pixels[7] &= ~(1UL << ColNum);
    pixels[7] |= ColVal;
  }else{
    for(int i=7; i>0; i--){
      pixels[i] &= ~(1UL << ColNum);
      ColVal = (((pixels[i-1] >> ColNum) & 1) << ColNum);
      pixels[i] |= ColVal;
    }
    ColVal = (uint32_t)WrappedBit << ColNum;
    pixels[0] &= ~(1UL << ColNum);
    pixels[0] |= ColVal;
  }
  if(update){DisplayMemory();}
}

// Shift everything up or down
void ShiftAllCol(bool dir, bool update){
  // Shifts every column up or down. Same wrapping logic, uses ShiftUp and ShiftDown
  for(int i=0; i<32; i++){ShiftCol(i, dir, update);}
}

// Send character to the display
void SendChar(uint8_t CharacterArray[8], uint8_t offset, bool update){
  for(int i=0; i<8; i++){
    pixels[i] &= ~((uint32_t)0x0000001f << offset);
    pixels[i] |= ((uint32_t)CharacterArray[i] << offset);
  }
  if(update){DisplayMemory();}
}

// Very cool clearing sequence
void ClearAll(){
  for(int i=7; i>=0; i--){
    pixels[i]=0xffffffff;
    DisplayMemory();
    delay(50);
  }
  for(int i=31; i>=0; i--){
    SetColumn(i, 0x00, 1);
    delayMicroseconds(12500);
  }
}

// Boot up Matrix
void BootMatrix(uint8_t data, uint8_t clock, uint8_t ChipSelect){
  _pins[0] = data; // Assign pin indexes
  _pins[1] = clock; // Assign pin indexes
  _pins[2] = ChipSelect; // Assign pin indexes
  for(int i=0; i<3; i++){pinMode(_pins[i], OUTPUT);}; // Set _pins to output
  for(int i=0; i<4; i++){SendPacket(shutdown, 1);} // Boot sequence
  for(int i=0; i<4; i++){SendPacket(DispTest, 0);} // Boot sequence
  for(int i=0; i<4; i++){SendPacket(brightness, 0x04);} // Boot sequence
  for(int i=0; i<4; i++){SendPacket(ScanLimit, 0x07);} // Boot sequence
  ClearAll(); // Just in case any pixels persist after exiting test mode
}