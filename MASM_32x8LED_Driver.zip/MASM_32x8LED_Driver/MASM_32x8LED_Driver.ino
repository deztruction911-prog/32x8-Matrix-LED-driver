#include "MASM_32x8LED_Driver.h"

void setup(){
  BootMatrix(22, 24, 26);
}

void loop(){
  // put your main code here, to run repeatedly:

}
